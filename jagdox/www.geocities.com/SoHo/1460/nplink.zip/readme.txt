----------------------------------------------------------------
                        = NPLINK =
                           
(c) Copyright 1996 by Nat!                              Freeware

$Id: readme.txt,v 1.1.1.1 1996/02/27 00:30:59 nat Exp $
----------------------------------------------------------------
This is a supplemental linker for PURE-C's own Linker.

It produces JAG and TOS binaries.


PRO:  pads DATA/BSS Modules to phrase alignment
      you get the source 
      supports the FORCE module thing, (plink doesn't)
      seems to produce much smaller output than PLINK

CON:  not quite as fast as plink
      can't do all that plink does
      can't do DR objects
		
Bugs, comments etc.                    nat@zumdick.rhein-main.de
----------------------------------------------------------------
Type nplink.ttp in a shell to get a little help.

Better use the -v flag, so you won't be surprised if the linker
makes a surprising matchup with names, that shouldn't fit.

The linker will NOT warn you about doubly defined names, since
it doesn't use a normal symbol table.



v0.3:	With verify tells you when it truncates to 8 characters to
		achieve a match. 8 char truncation is needed for the Pure-C
		libraries (strange but true) and for future DR-linkage

